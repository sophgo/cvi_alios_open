#!/usr/bin/python3
# -*- coding: utf-8 -*-
import logging
import os
import re
import sys
import yaml

FORMAT = "%(levelname)s: %(message)s"
logging.basicConfig(level=logging.INFO, format=FORMAT)
Storage_EMMC = 0
Storage_SPINAND = 1
Storage_SPINOR = 2
LBA_SIZE = 512


class YamlParser:
    @staticmethod
    def parse_size(size):
        units = {"B": 1, "K": 2 ** 10, "M": 2 **
                 20, "G": 2 ** 30, "T": 2 ** 40}
        size = size.upper()
        logging.debug("parsing size %s" % size)
        if not re.match(r" ", size):
            size = re.sub(r"([BKMGT])", r" \1", size)
            try:
                number, unit = [string.strip() for string in size.split()]
            except ValueError:
                number = size
                unit = "B"

        ret = int(float(number) * units[unit])

        return ret

    def parse(self, install=None):
        self.storage = "spinor"
        install_dir = install
        parts = []
        with open(self.yaml, mode='r', encoding='utf-8') as f:
            yaml_json_array = yaml.load(stream=f, Loader=yaml.FullLoader)
            if isinstance(yaml_json_array['partitions'], list):
                for json_list in yaml_json_array['partitions']:
                    p = dict()
                    p["part_size"] = int(json_list['size'])
                    if "filename" in json_list:
                        path = os.path.join(install_dir, json_list['filename'])
                        try:
                            file_size = os.stat(path).st_size
                        except:
                            file_size = 0
                        if file_size - 128 > p["part_size"]:
                            logging.error(
                                "Image: %s(%d) is larger than partition size(%d)"
                                % (json_list['filename'], file_size, p["part_size"])
                            )
                            raise OverflowError
                        p["file_path"] = path
                        p["file_name"] = json_list['filename']
                        logging.debug("size of " + path +
                                      " : " + str(file_size))
                    else:
                        file_size = 0
                    p["file_size"] = int(file_size)
                    p["label"] = json_list["name"]
                    p["mountpoint"] = (
                        json_list["mountpoint"] if "mountpoint" in json_list else None
                    )
                    p["type"] = json_list["type"] if "type" in json_list else ""
                    p["options"] = json_list["options"] if "options" in json_list else None
                    parts.append(p)

        if self.storage == "emmc":
            self.__calEmmcOffset(parts)
        elif self.storage == "spinor":
            self.__calNorOffset(parts)
        elif self.storage == "spinand":
            self.__calNandOffset(parts)
        else:
            logging.error("Unknown storage type")
            raise ValueError(self.storage)
        return parts

    def __calEmmcOffset(self, parts):
        start = 0
        for p in parts:
            p["offset"] = start
            start += p["part_size"]

    def __calNandOffset(self, parts):
        start = 0
        for p in parts:
            p["offset"] = start
            start += p["part_size"]

    def __calNorOffset(self, parts):
        start = 0
        for p in parts:
            p["offset"] = start
            start += p["part_size"]

    def getStorage(self):
        return self.storage

    def __init__(self, yaml):
        self.yaml = yaml
        self.storage = "emmc"
