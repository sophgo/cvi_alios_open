#!/usr/bin/python3
from cv_usb_util.cv_usb import cv_usb
import argparse
import logging
import os
import sys
import time
import cv_usb_util.cv_usb_pkt as pkt
from glob import glob
from array import array
from YamlParser import YamlParser
import yaml
from zipfile import ZipFile
from tempfile import mkdtemp
from io import BytesIO
from tempfile import TemporaryDirectory
import binascii
FORMAT = '%(levelname)s: %(message)s'
logging.basicConfig(level=logging.INFO, format=FORMAT)
parser = argparse.ArgumentParser(description='Create CVITEK device image')

header_size = 64
max_chunk_size = 16 * 1024 * 1024
uboot_vidpid = ""
uboot_cvi_vidpid = ""
CHUNK_TYPE_DONT_CARE = 0
CHUNK_TYPE_CRC_CHECK = 1


class ImagerBuilder(object):
    def __init__(self, storage: int, output_path):
        self.storage = storage
        self.output_path = output_path

    def packHeader(self, part):
        """
        Header format total 64 bytes
        4 Bytes: Magic
        4 Bytes: Version
        4 Bytes: Chunk header size
        4 Bytes: Total chunks
        4 Bytes: File size
        32 Bytes: Extra Flags
        12 Bytes: Reserved
        """
        with open(part["file_path"], "rb") as fd:
            magic = fd.read(4)
            if magic == b"CIMG":
                logging.debug("%s has been packed, skip it!" % part["file_name"])
                return
            fd.seek(0)
            Magic = array("b", [ord(c) for c in "CIMG"])
            Version = array("I", [1])
            chunk_header_sz = 64
            Chunk_sz = array("I", [chunk_header_sz])
            chunk_counts = part["file_size"] // max_chunk_size
            remain =  part["file_size"] - max_chunk_size * chunk_counts
            if (remain != 0):
                chunk_counts = chunk_counts + 1
            Totak_chunk = array("I", [chunk_counts])
            File_sz = array("I", [part["file_size"] + (chunk_counts * chunk_header_sz)])
            try:
                label = part["label"]
            except KeyError:
                label = "gpt"
            Extra_flags = array("B", [ord(c) for c in label])
            for _ in range(len(label), 32):
                Extra_flags.append(ord("\0"))

            #img = open(os.path.join(self.output_path, part["file_name"]), "wb")
            img = BytesIO()
            # Write Header
            for h in [Magic, Version, Chunk_sz, Totak_chunk, File_sz, Extra_flags]:
                h.tofile(img)
            img.seek(64)
            total_size = part["file_size"]
            offset = part["offset"]
            part_sz = part["part_size"]
            while total_size:
                chunk_sz = min(max_chunk_size, total_size)
                chunk = fd.read(chunk_sz)
                crc = binascii.crc32(chunk) & 0xFFFFFFFF
                chunk_header = self._getChunkHeader(chunk_sz, offset, part_sz, crc)
                img.write(chunk_header)
                img.write(chunk)
                total_size -= chunk_sz
                offset += chunk_sz
            #img.close()
        return img

    def _getChunkHeader(self, size: int, offset: int, part_sz: int, crc32: int):
        """
        Header format total 64 bytes
        4 Bytes: Chunk Type
        4 Bytes: Chunk data size
        4 Bytes: Program part offset
        4 Bytes: Program part size
        4 Bytes: Crc32 checksum
        """
        logging.info("size:%x, offset:%x, part_sz:%x, crc:%x" % (size, offset, part_sz, crc32))
        Chunk = array(
            "I",
            [
                CHUNK_TYPE_CRC_CHECK,
                size,
                offset,
                part_sz,
                crc32,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
            ],
        )
        return Chunk


def parse_Args():
    cur_dir = os.path.abspath(os.getcwd())

    parser.add_argument(
        '--image_dir',
        metavar='path',
        type=str,
        default=cur_dir,
        help='the folder path to dir inclued fip,rootfs kernel and xml')
    parser.add_argument(
        "--zipfile",
        metavar="path to upgrade.zip",
        type=str,
        help="the path of upgrade.zip")
    parser.add_argument(
        '--location',
        metavar="",
        type=str)
    parser.add_argument(
        '--pid',
        metavar='1001',
        default='1001',
        type=str)
    parser.add_argument(
        "-v",
        "--verbose",
        help="increase output verbosity",
        action="store_true")
    parser.add_argument("--mac",
                        metavar="mac address",
                        type=str,
                        help="set mac address")
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--serial', action='store_true', default=False)
    group.add_argument('--libusb', action='store_true', default=False)

    args = parser.parse_args()
    if args.zipfile:
        args.image_dir = mkdtemp()
        with ZipFile(args.zipfile, 'r') as zipObj:
            zipObj.extractall(args.image_dir)
    if args.verbose:
        logging.debug("Enable more verbose output")
        logging.getLogger().setLevel(level=logging.DEBUG)

    return args


def usage():
    parser.print_usage()


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller   """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.dirname(os.path.realpath(__file__))
    return os.path.join(base_path, relative_path)


def changeOffset(fd, offset):
    last_pos = fd.tell()
    """
    Since we cannot send cmd to device due to security issue. We can
    only modify the header information for changing the offset we
    want to program.
    """
    # Get Chunk header
    chunk_header = array('I')
    chunk_header.fromfile(fd, int(header_size / 4))
    chunk_header[2] = offset
    # Modify header according to the partition.xml
    fd.seek(last_pos)
    fd.write(chunk_header)
    fd.seek(last_pos)


def set_macaddress(usb, libusb, mac, timeout):
    global uboot_vidpid
    global uboot_cvi_vidpid

    if not libusb:
        usb.restart()
        usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)
        time.sleep(0.2)

    # Send setenv
    cmd = array('B', [ord(c) for c in "setenv ethaddr "])
    for c in [ord(ch) for ch in mac]:
        cmd.append(c)
    usb.send_req_data(pkt.CV_USB_PRG_CMD, 0, len(cmd) + 8, cmd, 1)

    # Send savenv
    cmd = array('B', [ord(c) for c in "saveenv"])
    usb.send_req_data(pkt.CV_USB_PRG_CMD, 0, len(cmd) + 8, cmd, 1)
    # Break command
    # usb.send_req_data(pkt.CV_USB_UBREAK, 0x04003000, 0, None)


def set_filesize(usb, libusb, filesize, timeout):
    global uboot_vidpid
    global uboot_cvi_vidpid

    if not libusb:
        usb.restart()
        usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)
        time.sleep(0.2)

    # Send setenv
    cmd = array('B', [ord(c) for c in "setenv filesize "])
    for c in [ord(ch) for ch in hex(filesize)]:
        cmd.append(c)

    usb.send_req_data(pkt.CV_USB_PRG_CMD, 0, len(cmd) + 8, cmd, 1)


def reboot_device(usb, libusb, timeout):
    global uboot_vidpid
    global uboot_cvi_vidpid

    usb.send_req_data(pkt.CV_USB_UBREAK, 0x04003000, 0, None)
    usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)

    usb.send_req_data(pkt.CVI_USB_REBOOT, 0x04003000, 0, None)
    logging.info("reboot device done")


def main():
    global uboot_vidpid
    global uboot_cvi_vidpid
    args = parse_Args()
    image_dir = args.image_dir
    location = args.location
    pid = args.pid
    i = 0
    # location != None is usb_mult_dl
    yaml = glob(os.path.join(image_dir, "config*.yaml"))
    if len(yaml) != 1:
        logging.error("Cannot get correct partition yaml in %s", image_dir)
        usage()
        return

    yamlParser = YamlParser(yaml[0])
    parts = yamlParser.parse(image_dir)

    if (not args.serial and not args.libusb) or args.serial:
        driver = "pyserial"
        timeout = 90
    else:
        driver = "libusb"
        timeout = 30
    logging.info("Using %s" % driver)
    usb = cv_usb(driver)
    files = []
    prog_parts = []
    if yamlParser.getStorage() == "emmc":
        fip_path = os.path.join(image_dir, "fip.bin")
        files.append(fip_path)
        prog_parts.append({})  # Add empty dict for fip

    uboot_vidpid = "VID:PID=30B1:" + pid
    uboot_cvi_vidpid = "VID:PID=3346:" + pid
    usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)

    # get image addr
    recvbuf = usb.recive_data(0, 8)
    hex_arr = [hex(x)[2:].rjust(2, '0') for x in recvbuf]
    hex_arr.reverse()
    hex_join = "0x" + "".join(hex_arr)
    pkt.IMG_ADDR = int(hex_join, 16)
    print("send to addr: ", hex_join)

    storage = yamlParser.getStorage()
    tmp = TemporaryDirectory()
    imgBuilder = ImagerBuilder(storage, tmp.name)

    # set_filesize(usb, driver == "libusb", os.path.getsize(os.path.join(image_dir, "fip.bin")), timeout)

    for p in parts:
        if p['file_size'] != 0:
            #files.append(p['file_path'])
            fd = imgBuilder.packHeader(p)
            fd.seek(0)
            prog_parts.append(p)

        #for i, f in enumerate(files):
            if(location is not None):
                # For UI Tool
                print("SEND FILE %s " % files[i] + "LOCATION=" + location + "\r\n")
            else:
                logging.info("SEND FILE %s " % p['file_path'] + "\r\n")

            # if i == 0:
            #     usb.send_file(f, pkt.IMG_ADDR, 0)
            #     usb.send_req_data(pkt.CV_USB_UBREAK, 0x04003000, 0, None)
            #     usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)
            #     time.sleep(0.02)
            # else:
            if (driver == "pyserial"):
                usb.restart()
                logging.info("Connecting to u-boot... ")
                usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)
                time.sleep(0.02)
            #fd = open(f, 'r+b')
            usb.send_chunk(fd, header_size, pkt.IMG_ADDR, 0)
            fd.seek(0)
            header = array('I')
            header.fromfile(fd, int(header_size / 4))
            chunk_header_sz = header[2]
            cnt = header[3]
            file_size = header[4]
            remain_file_size = file_size
            offset = prog_parts[i]["offset"]
            for j in range(cnt):
                if (j > 0 and driver == "pyserial"):
                    usb.restart()
                    logging.info("Connecting to u-boot... ")
                    usb.query([uboot_vidpid, uboot_cvi_vidpid], timeout)
                    time.sleep(0.02)
                send_size = min(remain_file_size, max_chunk_size + chunk_header_sz)
                # location != None is usb_mult_dl
                # if(location is None):
                #    changeOffset(fd, offset)
                usb.send_chunk(
                    fd,
                    send_size,
                    pkt.IMG_ADDR,
                    0,
                )
                logging.info("CVI_USB_PROGRAM")
                usb.send_req_data(pkt.CVI_USB_PROGRAM, 0x04003000, 0, None, 1)
                remain_file_size -= send_size
                offset += max_chunk_size
                if file_size == fd.tell():
                    break
                fd.close()
            i = i + 1

    if args.mac:
        set_macaddress(usb, driver == "libusb", args.mac, timeout)

    reboot_device(usb, driver, timeout)
    logging.info("USB download complete")


if __name__ == '__main__':
    main()
